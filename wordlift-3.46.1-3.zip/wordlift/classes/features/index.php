<?php

use Wordlift\Features\Response_Adapter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

new Response_Adapter();
