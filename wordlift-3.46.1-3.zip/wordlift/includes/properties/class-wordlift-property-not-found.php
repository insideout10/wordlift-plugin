<?php

/**
 * This file is included by the class-wordlift-property-service.php file and defines
 * the {@link Wordlift_Property_Not_Found} class.
 */

/**
 * A class to represent properties not found on entities.
 *
 * @since 3.8.0
 */
class Wordlift_Property_Not_Found {

}
