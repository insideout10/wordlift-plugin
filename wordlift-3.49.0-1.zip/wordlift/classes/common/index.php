<?php
/**
 * This namespace consists of common classes, interfaces which are used by other features of WLP,
 * this file is present for documentation.
 *
 * @since 3.31.0
 * @author Naveen Muthusamy <naveen@wordlift.io>
 */
