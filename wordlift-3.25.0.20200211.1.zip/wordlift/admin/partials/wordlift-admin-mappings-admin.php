<?php
// Prevent php-compat-5.3 from failing when it doesn't find any PHP tags.
?>
<div id="wl-mappings-container" style='width: 100%;'></div>
