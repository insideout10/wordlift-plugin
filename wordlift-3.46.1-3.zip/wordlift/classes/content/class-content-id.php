<?php

/**
 * An interface that Entity IDs must implement.
 */

namespace Wordlift\Content;

interface Content_Id {

}
