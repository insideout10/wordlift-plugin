<?php
// Prevent php-compat-5.3 from failing when it doesn't find any PHP tags.
?>
<div id="wl-edit-mappings-container" style="width: 95%;"></div>