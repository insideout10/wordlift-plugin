<?php

namespace Wordlift\Wordpress;

interface Page {

	public function get_menu_slug();

}
