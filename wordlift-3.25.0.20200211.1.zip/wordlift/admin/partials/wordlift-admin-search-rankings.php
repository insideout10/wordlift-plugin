<div class="wrap">
    <h1><?php echo esc_html_x( 'Search Rankings', 'Page title', 'Wordlift' ); ?></h1>

    <div id="treemap"></div>

    <div class="pull-right">powered by <a target="_blank" href="https://www.woorank.com/"><img style="height: 18px; vertical-align: top;" src="<?php echo plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'images/logo-woorank.svg'; ?>"></a></div>
</div>