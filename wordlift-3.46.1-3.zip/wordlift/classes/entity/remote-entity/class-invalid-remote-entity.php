<?php

namespace Wordlift\Entity\Remote_Entity;

class Invalid_Remote_Entity implements Remote_Entity {

	public function get_name() {
		// TODO: Implement getName() method.
	}

	public function get_description() {
		// TODO: Implement getDescription() method.
	}

	public function get_same_as() {
		// TODO: Implement getSameAs() method.
	}

	public function get_types() {
		// TODO: Implement getTypes() method.
	}
}
