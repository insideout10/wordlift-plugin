<?php

namespace Wordlift\Analysis\Entity_Provider;

interface Entity_Provider {

	public function get_entity( $uri );

}
